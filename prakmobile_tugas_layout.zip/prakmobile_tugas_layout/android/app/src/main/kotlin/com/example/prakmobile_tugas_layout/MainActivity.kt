package com.example.prakmobile_tugas_layout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
